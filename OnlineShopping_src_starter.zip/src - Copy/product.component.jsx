import React from "react";

export default class Product extends React.Component {
  render() {
    return (
      <div >
        <div >       
        <h1>{this.props.productdetails.title}</h1>
        <img
          src={this.props.productdetails.ImageUrl}
          height="100px"
          width="100px"
        />
        <br />
        <strong>Price : </strong> {this.props.productdetails.price} <br />
        <strong>Quantity : </strong> {this.props.productdetails.quantity} <br />
        <strong>Rating : </strong> {this.props.productdetails.rating} <br />
        <button >
          {this.props.productdetails.likes}
        </button>        
        </div>
      </div>
    );
  }
}
