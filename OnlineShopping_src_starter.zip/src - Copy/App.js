
import './App.css';
import ShoppingCart from './shoppingcart.component';

function App() {
  return (
    <div>
      <ShoppingCart></ShoppingCart>
    </div>
  );
}

export default App;
