import React from "react";
import './product.style.css';

export default class Product extends React.Component {
  
  constructor(props){
    super(props);
    console.log('Product Created..')
    this.state = {currLikes:this.props.productdetails.likes};
  }
  IncrementLikes(){
    console.log('U Clicked !');
    //this.props.productdetails.likes++;// props are read-only !
    //this.state.currLikes++; // state is immutable !
    this.setState({currLikes:this.state.currLikes+1}); // setState() changes the state !
  }
    render() {    
    return (
      <div className="col-md-3">
        <div className="productStyle" >       
        <h1>{this.props.productdetails.title}</h1>
        <img
          src={this.props.productdetails.ImageUrl}  height="100px"   width="100px"  />
        <br />
        <strong>Price : </strong> {this.props.productdetails.price} <br />
        <strong>Quantity : </strong> {this.props.productdetails.quantity} <br />
        <strong>Rating : </strong> {this.props.productdetails.rating} <br />
        <button className="btn btn-primary" onClick={this.IncrementLikes.bind(this)}>
          {this.state.currLikes}
        </button>     {" "}
        <button className="btn btn-danger" onClick={()=>this.props.deleteproducthandler(this.props.productdetails.id)}>
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
  <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
  <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4L4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
</svg> 
        </button>   
        </div>
      </div>
    );
  }
}
