import React from 'react';
export class BasicComponent extends React.Component{
    render(){
        return <h1>Basic Component </h1>
    }
}