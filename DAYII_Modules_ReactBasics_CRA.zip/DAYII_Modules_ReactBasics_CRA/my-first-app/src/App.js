import React from "react";
import "./App.css";
import { BasicComponent } from "./basic.component";
import { Course } from "./course.component";

class App extends React.Component {
  constructor(){
    super();
    this.course1 = {name:"React",price:3000};  
    this.course2 = {name:"Redux",price:4000};  
    this.course3 = {name:"MobX",price:5000};  
  }
    render() {      
    return (
      <div>
        <Course coursedetails={this.course1} />
        <Course coursedetails={this.course2} />
        <Course coursedetails={this.course3} />
      </div>
    );
  }
}

export default App;
