import React from 'react';
export class Course extends React.Component {
    render() {
        return <div>
            <h1> {this.props.coursedetails.name} </h1>
            <h4>{this.props.coursedetails.price}</h4>
        </div>
    }
}