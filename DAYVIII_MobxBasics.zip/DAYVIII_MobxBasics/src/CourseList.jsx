import { useObserver } from 'mobx-react-lite';
import React from 'react'
import {StoreContext} from './storeprovider';

export const CourseList = (props) => {
    let store = React.useContext(StoreContext);
    return useObserver(()=>(
        <ul>
            {store.courses.map(courseItem=><li key={courseItem}>{courseItem}</li>)}
        </ul>
    ))
} 

export default CourseList