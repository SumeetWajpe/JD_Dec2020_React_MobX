import logo from './logo.svg';
import './App.css';
import {makeAutoObservable} from 'mobx';
import {observer} from 'mobx-react-lite'
import StoreProvider from './storeprovider';
import CourseList from './CourseList';
import { CourseForm } from './CourseForm';
import CourseCount from './CourseCount';
// Store
// class AppState{
//   count=0; 
//   constructor(){
//       makeAutoObservable(this);
//       setInterval(()=>{
//         this.count +=1;       
//       },1000);
//   }
//   //action
//   reset=()=>{
//     this.count = 0;
//   }
// }
// export const Counter = observer(({appState}) => {
//   return(
//     <div>
//      <button onClick={appState.reset}>Counter : {appState.count}</button>
//     </div>
//   )
// })
// function App() {
//   return (
//     <div className="App">
//      <Counter appState={new AppState()} />
    
//     </div>
//   );
// }
//export default App;



function App() {
  return (
    <div>     
     <StoreProvider>
       <CourseCount />
       <CourseList />
       <CourseForm />
     </StoreProvider>
    </div>
  );
}

export default App;
