import { useObserver } from 'mobx-react-lite';
import React from 'react'
import {StoreContext} from './storeprovider';

export const CourseCount = (props) => {
    let store = React.useContext(StoreContext);
    return useObserver(()=>(
        <div>
            <h1>{store.courseCount} courses !</h1>
        </div>
    ))
}

export default CourseCount;