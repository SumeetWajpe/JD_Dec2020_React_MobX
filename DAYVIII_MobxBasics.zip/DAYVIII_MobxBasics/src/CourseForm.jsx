import React, { useState } from 'react'
import {StoreContext} from './storeprovider';

export const CourseForm = (props) => {
    let [newCourse,setNewCourse] = useState('');
    let store = React.useContext(StoreContext);
    return(
        <div>
           <form onSubmit={e=>{
            store.addCourse(newCourse);
            setNewCourse("");// clear the textbox
            e.preventDefault();
           }}>
               <input type="text" value={newCourse} onChange={e=>setNewCourse(e.target.value)} />
               <button type="submit">Add</button>
           </form>
        </div>
    )
}

export default CourseForm