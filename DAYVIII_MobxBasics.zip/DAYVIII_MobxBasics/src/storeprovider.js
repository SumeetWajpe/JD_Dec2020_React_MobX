import { useLocalStore } from 'mobx-react-lite'
import React from 'react'


export let StoreContext = React.createContext();
export const StoreProvider = (props) => {    
  var store =  useLocalStore(()=>({
        courses:['HTML5','React'], // app state !
        addCourse:newCourse=>{ // action
            store.courses.push(newCourse);// store is mutable !            
        },
        get courseCount(){ // computed
            return store.courses.length;
        }
    }))   
    return(
        <StoreContext.Provider value={store}>
            {props.children}
        </StoreContext.Provider>
    )
}
export default StoreProvider;