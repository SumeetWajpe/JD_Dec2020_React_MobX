import React from 'react';

class Message extends React.Component {    
    render() {        
        return (
            <div>
                <h3>Message : </h3>
                <strong>{this.props.msg}</strong>
            </div>
        );
    }
}

export default Message;
