import React, { useState } from 'react'

let errormessage = '';
let newProduct,setNewProduct,err;
export const AddNewProduct = (props) => {    
    [newProduct,setNewProduct] =  useState({
        id:0,       
        title:'',
        likes:0,
        price:0,
        quantity:0,
        rating:0,
        ImageUrl:'https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/No_image_available.svg/600px-No_image_available.svg.png'
    
    });
    return(
        <form onSubmit={(e)=>{e.preventDefault(); console.log(newProduct)}}>
            {err}
            Id : <input type="text" required className="form-control" onChange={ e=> ValidateId(e)  } />
            Title : <input type="text" className="form-control" onChange={e=> setNewProduct({...newProduct,title:e.target.value}) } /> 
            Quantity : <input type="number" className="form-control" onChange={e=> setNewProduct({...newProduct,quantity:e.target.value}) } /> 
            Price : <input type="text" className="form-control" onChange={e=> setNewProduct({...newProduct,price:e.target.value}) } /> 
            Rating : <input type="text" className="form-control" onChange={e=> setNewProduct({...newProduct,rating:e.target.value}) } /> 
            Likes : <input type="text" className="form-control" onChange={e=> setNewProduct({...newProduct,likes:e.target.value}) } /> 
            ImageUrl : <input type="text" className="form-control" value={newProduct.ImageUrl} onChange={e=> setNewProduct({...newProduct,ImageUrl:e.target.value}) } /> 
            <button className="btn btn-success" type="submit">
                Add Product
            </button>
        </form>
    )
}

function ValidateId(e){
    let id = e.target.value;
    if(id<5){
        // error !
        errormessage = 'The Id should be less than 5 !';
        err = <p className="alert alert-danger">{errormessage}</p>
        console.log(errormessage);
    }
    else if(id>5){
        setNewProduct({...newProduct,id});
        err='';
        errormessage='';
    }
    else {
        err='';
        errormessage='';        
    }
}

export default AddNewProduct