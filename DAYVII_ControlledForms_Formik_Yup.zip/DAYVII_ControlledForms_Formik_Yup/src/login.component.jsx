import React from 'react';
import { useFormik } from 'formik'; // useFormik hook

function validate(values){
    let errors={};
    if(!values.userpassword){
        errors.userpassword = 'Password Required !';
    }
    if(!values.useremail){
        errors.useremail = 'Email Required !'
    }else if(!/^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i.test(values.useremail)){
        errors.useremail = 'Invalid Email address !'
    }
    return errors;
}
export const Login = (props) => {
    let formik = useFormik({
        initialValues: {useremail: '',userpassword: ''},validate,onSubmit: values => console.log(values) 
    })
    return (
        <div className="card">
            <div className="card-body">
                <form onSubmit={formik.handleSubmit}>
                    {formik.errors.useremail && formik.touched.useremail ? <p className="alert alert-danger">{formik.errors.useremail}</p> : null }
                    Email : <input type="email" id="useremail" name="useremail"
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.useremail}
                    /><br />
                    {formik.errors.userpassword && formik.touched.userpassword ? <p className="alert alert-danger">{formik.errors.userpassword}</p> : null }

            Password : <input type="password" id="userpassword" name="userpassword"
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.userpassword}
                    />
                    <button type="submit" className="btn btn-primary">Login</button>
                </form>
            </div>
        </div>

    )
}

export default Login;