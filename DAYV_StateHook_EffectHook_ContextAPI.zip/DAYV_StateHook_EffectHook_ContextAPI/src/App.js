
import './App.css';
import Message from './message.component';
import Posts from './posts.component';
import ShoppingCart from './shoppingcart.component';
import React from 'react';
import {MessageAsFunctional} from './functional.component';
import { Counter } from './statehook.counter';
import PostsWithEffectHook from './postswitheffect';
import { ComponentParent } from './contextapi';

class App extends React.Component{
  constructor(){
    super();
    this.state = {message:''}
  }
  render(){
    return (
      <div>
        {/* <ShoppingCart>            
        </ShoppingCart> */}
        {/* <Posts></Posts> */}
        {/* Message : <input type="text"  onInput={(e)=>this.setState({message:e.target.value})}  />
        <Message msg={this.state.message}></Message>
        <hr/>
        <MessageAsFunctional msg={this.state.message}></MessageAsFunctional> */}
        {/* <Counter /> */}
        
        {/* <PostsWithEffectHook /> */}

        <ComponentParent />
       
      </div>
    );
  }
}

export default App;
