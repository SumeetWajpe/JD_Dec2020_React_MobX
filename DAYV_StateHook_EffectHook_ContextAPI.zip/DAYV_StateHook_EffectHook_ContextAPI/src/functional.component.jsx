
export function MessageAsFunctional(props){
    
    return <h1>{props.msg}</h1>
}

/*
1. No State !
2. No lifecycle methods
3. No (this)
4. No render
*/