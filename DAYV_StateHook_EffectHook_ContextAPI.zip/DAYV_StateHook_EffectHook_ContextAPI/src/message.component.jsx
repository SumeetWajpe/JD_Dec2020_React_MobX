import React from 'react';

class Message extends React.Component {    
    render() {        
        return (
            <div>
                <strong>{this.props.msg}</strong>
            </div>
        );
    }
}

export default Message;
