import React from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

class Posts extends React.Component {
    constructor(props) {
        super(props);
        this.state = { allPosts: [] }
    }
    componentDidMount() {
        // axios
        let promise = axios.get('https://jsonplaceholder.typicode.com/posts');
        promise.then(response => this.setState({ allPosts: response.data })).
            catch(err => console.log(err));
    }
    render() {
        let allPostsToBeCreated = this.state.allPosts.map(p => <li key={p.id}>
            <Link to={"/postdetails/"+p.id}>{p.title}</Link> 
            </li>)
        let content;
        if (allPostsToBeCreated.length > 0) {
            content = <ul>
                {allPostsToBeCreated}
            </ul>
        }
        else{
            //content = <img src="https://media0.giphy.com/media/xTk9ZvMnbIiIew7IpW/giphy.gif"/>
            content = "Loading.."
        }
        return (
            <div>
                <h1>All Posts</h1>
                {content}
            </div>
        );
    }
}

export default Posts;
