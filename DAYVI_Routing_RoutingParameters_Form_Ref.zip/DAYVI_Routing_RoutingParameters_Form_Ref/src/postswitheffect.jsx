import React, { useEffect, useState } from 'react'
import axios from 'axios';

export const PostsWithEffectHook = (props) => {   
    let [allPosts,setAllPosts] = useState([]);

        useEffect(()=>{
            console.log('Within Effect Hook !')
            let promise = axios.get('https://jsonplaceholder.typicode.com/posts');
        promise.then(response => setAllPosts(response.data) ).
            catch(err => console.log(err));
        },[]);        

        let allPostsToBeCreated = allPosts.map(p => <li key={p.id}>{p.title}</li>)

    return (
    <div>
           <h1>All Posts (With Effect Hooks)</h1>
           <ul>
               {allPostsToBeCreated}
           </ul>
        </div>
    )
    
}

export default PostsWithEffectHook;