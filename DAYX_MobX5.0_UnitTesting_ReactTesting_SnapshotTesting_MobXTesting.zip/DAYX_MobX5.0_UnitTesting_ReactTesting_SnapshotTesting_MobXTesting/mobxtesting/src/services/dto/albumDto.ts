export interface AlbumDto {
  userId: number;
  id: number;
  title: string;
}
