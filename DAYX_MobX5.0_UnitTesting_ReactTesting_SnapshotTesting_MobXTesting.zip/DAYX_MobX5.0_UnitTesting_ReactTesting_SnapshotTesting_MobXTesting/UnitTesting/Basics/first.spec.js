describe("A suite", function() {
    it("contains spec with an expectation", function() {
      expect(true).toBe(true);
    });
  });


  function Addition(x,y){
      return x+ y;
  }

  describe("An addition suite", function() {
    it("should add two numbers", function() {
      expect(Addition(20,30)).toBe(50);
    });
  });