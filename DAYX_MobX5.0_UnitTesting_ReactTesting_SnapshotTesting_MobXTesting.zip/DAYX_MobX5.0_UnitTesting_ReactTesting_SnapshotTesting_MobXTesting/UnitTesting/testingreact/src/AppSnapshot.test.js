import React from 'react';
import renderer from 'react-test-renderer';
import App from './App';

describe('test snapshot of App',()=>{
    it('compares App snapshot',()=>{
      let tree = renderer.create(<App/>).toJSON();
      expect(tree).toMatchSnapshot();
    })
})