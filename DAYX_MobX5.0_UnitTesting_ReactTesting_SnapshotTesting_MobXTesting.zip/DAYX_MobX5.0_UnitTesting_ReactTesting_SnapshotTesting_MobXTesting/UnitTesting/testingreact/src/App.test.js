import { render, screen } from '@testing-library/react';
import App from './App';
import Enzyme,{shallow} from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

Enzyme.configure({ adapter: new Adapter() });

// If state.count == 0
describe('app state count initialization',()=>{
  it('state count to be 0',()=>{
    let appInstance = shallow(<App />); /// uses this to generate DOM !
    let count = appInstance.state().count;
    expect(count).toBe(0);
  })

  it('cheks the incremented value of count in p (html)',()=>{
    let appInstance = shallow(<App />); /// uses this to generate DOM !
    // access the (DOM) button -> click -> p innerText is count 1
    let btn = appInstance.find('button');
    btn.simulate('click');
    let pText = appInstance.find('p').text();
    expect(pText).toEqual('Count : 1');
  })
})
