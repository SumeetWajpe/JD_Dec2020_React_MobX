import logo from './logo.svg';
import './App.css';
import {observable} from 'mobx';
import {observer} from 'mobx-react-lite'
// Store
class AppState{
  @observable count=0; 
  constructor(){     
      setInterval(()=>{
        this.count +=1;       
      },1000);
  }
  //action
  reset=()=>{
    this.count = 0;
  }
}
export const Counter = observer(({appState}) => {
  return(
    <div>
     <button onClick={appState.reset}>Counter : {appState.count}</button>
    </div>
  )
})
function App() {
  return (
    <div className="App">
     <Counter appState={new AppState()} />
    </div>
  );
}

export default App;
