import React, { Component } from 'react';

let CounterContext = React.createContext();
export class MyProvider extends Component {
    constructor(props) {
        super(props);
        this.state = { count: 100 }
    }
    render() {
        return (
            <CounterContext.Provider value={
                {
                    state: this.state,
                    incrementCount: () => this.setState({ count: this.state.count + 1 })
                }
            } >
                {this.props.children}
            </CounterContext.Provider>
        );
    }
}

export class ComponentParent extends Component {
    render() {
        return (
            <MyProvider>
                <div>
                    <h1>ComponentParent</h1>
                    <ComponentIntermidiate />
                </div>
            </MyProvider>
        );
    }
}
export class ComponentIntermidiate extends Component {
    render() {
        return (
            <div>
                <h1>ComponentIntermidiate</h1>
                <ComponentLeaf />
            </div>
        );
    }
}
export class ComponentLeaf extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (

            <CounterContext.Consumer>
                {
                    context => <div>
                        <h1>ComponentLeaf</h1>
                        {context.state.count}
                        <button className="btn btn-primary" onClick={context.incrementCount}>
                            ++
                        </button>
                    </div>

                }
            </CounterContext.Consumer>

        );
    }
}
