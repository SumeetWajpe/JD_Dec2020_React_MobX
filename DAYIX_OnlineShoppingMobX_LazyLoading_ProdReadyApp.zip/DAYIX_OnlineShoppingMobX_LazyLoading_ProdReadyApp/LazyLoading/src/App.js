import "./App.css";
import Message from "./message.component";
import Posts from "./posts.component";
import ShoppingCart from "./shoppingcart.component";
import React, { lazy,Suspense } from "react";
import { MessageAsFunctional } from "./functional.component";
import { Counter } from "./statehook.counter";
import PostsWithEffectHook from "./postswitheffect";
import { ComponentParent } from "./contextapi";
import { BrowserRouter, Route, Switch, Link, Redirect } from "react-router-dom";
//import PostDetails from "./postdetails.component";
//import AddNewProduct from "./addnewproduct.component";
import Login from "./login.component";
import { ValidationSchemaExample } from "./formikwithyup.component";

let AddNewProduct = lazy(()=> import('./addnewproduct.component'));
let PostDetails = lazy(()=> import('./postdetails.component'));

let loader = () => <strong>Loading..</strong>
class App extends React.Component {
  constructor() {
    super();
    this.state = { message: "" };
  }
  render() {
    return (
      <div>
        <BrowserRouter>
          <nav className="navbar navbar-expand-sm bg-dark navbar-dark">
            <ul className="navbar-nav">
              <li className="nav-item active">
                <Link className="nav-link" to="/">
                  Home
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/newproduct">
                  New Product
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/posts">
                  Posts
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/postseffect">
                  Posts (With Effect)
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/message">
                  Message
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/login">
                  Login
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/signup">
                  Sign Up
                </Link>
              </li>
            </ul>
          </nav>
         
          <Switch>
            <Route path="/" component={ShoppingCart} exact></Route>
            <Route path="/newproduct" render={()=>(
              <Suspense fallback={loader()}>
              <AddNewProduct></AddNewProduct>
            </Suspense>
            )
             
            }></Route>            
            <Route path="/login" component={Login}></Route>
            <Route path="/signup" component={ValidationSchemaExample}></Route>

           
            <Route path="/posts" component={Posts}></Route>
            <Route path="/postdetails/:id" render={ (routerProps)=>(
              <Suspense fallback={loader()}>
              <PostDetails {...routerProps}></PostDetails>
            </Suspense>
            )

            }></Route>
            <Route path="/postseffect" component={PostsWithEffectHook}></Route>
            <Route path="/message" render={()=><Message msg="Hola !" />}></Route>            
            
            <Route path="**" render={()=> <Redirect to="/" />}></Route>
            {/* <Route path="**" render={()=><h1 style={{color:'red'}}>404 ! Resource not found !</h1>} ></Route> */}

          </Switch> 
        </BrowserRouter>
      </div>
    );
  }
}

export default App;

{
  /* <ShoppingCart>            
        </ShoppingCart> */
}
{
  /* <Posts></Posts> */
}
{
  /* Message : <input type="text"  onInput={(e)=>this.setState({message:e.target.value})}  />
        <Message msg={this.state.message}></Message>
        <hr/>
        <MessageAsFunctional msg={this.state.message}></MessageAsFunctional> */
}
{
  /* <Counter /> */
}

{
  /* <PostsWithEffectHook /> */
}

{
  /* <ComponentParent /> */
}
