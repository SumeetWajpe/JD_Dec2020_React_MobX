import { useState } from "react";
export function Counter(){
   let [count,setCount] =  useState(0); // returns an array [initialState,methodChangescount] // state hook !
   let [age,setAge] = useState(18);

    return <div>
        <h3>{count}</h3>
       
        <input type="button" value="++" onClick={()=>setCount(count+1)} /> <br/>
        <h3>{age}</h3>

        <input type="button" value="Age++" onClick={()=>setAge(age+10)} />

        <input type="button" value="All++" onClick={()=>{
            setAge(age+10);
            setCount(count+1)
        }           
    } />


    </div>
}