import { useObserver } from 'mobx-react-lite';
import React, { useContext, useEffect } from 'react'
import { StoreContext } from './storeprovider';
import axios from 'axios';
import { Link } from 'react-router-dom';

export const Posts = (props) => {
    let storeContext = useContext(StoreContext)
    useEffect(() => {
        let promise = axios.get('https://jsonplaceholder.typicode.com/posts');
        promise.then(response => storeContext.posts = response.data).
            catch(err => console.log(err));
    }, []);
    return useObserver(() => (
        <div>
            <h1>All Posts (With MobX)</h1>
            {storeContext.posts.map(p => <li key={p.id}>
                <Link to={"/postdetails/" + p.id}>{p.title}</Link>
            </li>)}
        </div>
    ))
}

export default Posts