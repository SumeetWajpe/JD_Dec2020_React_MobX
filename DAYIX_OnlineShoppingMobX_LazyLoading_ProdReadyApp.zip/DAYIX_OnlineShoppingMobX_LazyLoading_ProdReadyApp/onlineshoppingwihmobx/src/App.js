import logo from './logo.svg';
import './App.css';
import { StoreProvider } from './storeprovider';
import ShoppingCart from './shoppingcart';
import Posts from './posts';
import { BrowserRouter, Route, Switch, Link, Redirect } from "react-router-dom";
import PostDetails from './postdetails';

function App() {
  return (
    <StoreProvider>
         <BrowserRouter>
          <nav className="navbar navbar-expand-sm bg-dark navbar-dark">
            <ul className="navbar-nav">
              <li className="nav-item active">
                <Link className="nav-link" to="/">
                  Home
                </Link>
              </li>
              {/* <li className="nav-item">
                <Link className="nav-link" to="/newproduct">
                  New Product
                </Link>
              </li> */}
              <li className="nav-item">
                <Link className="nav-link" to="/posts">
                  Posts
                </Link>
              </li>
             
             
            </ul>
          </nav>
         
          <Switch>
            <Route path="/" component={ShoppingCart} exact></Route>
            {/* <Route path="/newproduct" component={AddNewProduct}></Route>             */}
            <Route path="/posts" component={Posts}></Route>
            <Route path="/postdetails/:id" component={PostDetails}></Route>
            
            <Route path="**" render={()=> <Redirect to="/" />}></Route>
            {/* <Route path="**" render={()=><h1 style={{color:'red'}}>404 ! Resource not found !</h1>} ></Route> */}

          </Switch> 
        </BrowserRouter>
      
    </StoreProvider>
  );
}

export default App;
