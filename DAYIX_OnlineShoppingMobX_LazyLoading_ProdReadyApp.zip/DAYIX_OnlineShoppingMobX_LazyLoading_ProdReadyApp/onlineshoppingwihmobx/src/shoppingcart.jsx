import { useObserver } from 'mobx-react-lite';// functional components | class based <Observer> mobx-react
import React, { useContext } from 'react'
import { Product } from './product';
import { StoreContext } from './storeprovider'

export const ShoppingCart = (props) => {
    let storeContext = useContext(StoreContext);
    return useObserver(() => (
        <React.Fragment>
            <div className="jumbotron">
                <h1>Online Shopping</h1>
            </div>
            <div className="row">
                {storeContext.products.map((p) => (
                    <Product productdetails={p} key={p.id} />
                ))}
            </div>
        </React.Fragment>
    ))
}
export default ShoppingCart