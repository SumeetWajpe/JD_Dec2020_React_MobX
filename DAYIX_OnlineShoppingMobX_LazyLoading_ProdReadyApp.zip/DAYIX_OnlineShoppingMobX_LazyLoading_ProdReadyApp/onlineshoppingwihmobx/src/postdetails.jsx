import React, { useContext, useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
import { useObserver } from "mobx-react-lite";
import { StoreContext } from "./storeprovider";

export const PostDetails = (props) => {
    let storeContext = useContext(StoreContext);
    
    const [singlepost,setSinglePost] = useState({});
    useEffect(()=>{
        let index = storeContext.posts.findIndex(p=>p.id == params.id);      
       setSinglePost(storeContext.posts[index]);
    },[])

    const {match:{params}} = props;
    let history = useHistory();
    return useObserver(()=>(
        <div>
            <div className="jumbotron">
                <h1> Post Details </h1>               
            </div>   
                <h3>Id : { singlepost.id}</h3>
                <h3>User Id : { singlepost.userId}</h3>
                <h3>Title : { singlepost.title}</h3>
                <h3>Body : { singlepost.body}</h3>    
                <button className="btn btn-primary" onClick={()=>{history.goBack()}}>
                    Go Back to Posts
                </button>     
        </div>
    ))
}



export default PostDetails;